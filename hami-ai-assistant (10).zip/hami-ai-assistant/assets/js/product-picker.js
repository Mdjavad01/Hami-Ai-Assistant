/**
 * Hami AI Assistant — product picker (product-content screen only).
 *
 * Loaded exclusively on its own screen by Haa_Module_Product_Content::assets(),
 * so a store that never uses this module downloads nothing here.
 *
 * The server returns a flat parent => child category list and one page of
 * product rows; the tree, the checkbox states and the selection set are built
 * here. Neither a full catalogue nor a full selection ever crosses the wire in
 * one payload or lands in the DOM.
 */
(function () {
	'use strict';

	var root = document.querySelector('[data-haai-prodpicker]');
	var cfg = window.haaiPicker || {};
	if (!root || !cfg.ajax) return;

	var i18n = cfg.i18n || {};
	var CAP = parseInt(cfg.cap || 500, 10);

	function qs(sel, ctx) { return (ctx || root).querySelector(sel); }
	function qsa(sel, ctx) { return Array.prototype.slice.call((ctx || root).querySelectorAll(sel)); }
	function on(el, ev, fn) { if (el) el.addEventListener(ev, fn); }
	function esc(s) {
		return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
		});
	}

	/* ------------------------------------------------------------------
	 * State
	 * ---------------------------------------------------------------- */

	var terms = [];                 // flat rows: {id,parent,name,count}
	var kidsOf = {};                // parent id => [rows]
	var nodeById = {};              // id => {row, children, input, branch}
	var chosenCats = {};            // term id => 1  (the filter set)
	var selected = {};              // product id => title (the batch set)
	var page = 1;
	var per = parseInt(cfg.per || 20, 10);
	var pages = 1;
	var treeQuery = '';
	var loading = false;

	var treeBox = qs('[data-haai-tree]');
	var treeQ = qs('[data-haai-tree-q]');
	var childToggle = qs('[data-haai-tree-children]');
	var body = qs('[data-haai-pbody]');
	var allBox = qs('[data-haai-pall]');
	var selBar = qs('[data-haai-selbar]');
	var selCount = qs('[data-haai-selcount]');
	var pager = qs('[data-haai-ppager]');
	var counter = qs('[data-haai-pcounter]');
	var info = qs('[data-haai-pinfo]');
	var batchIds = qs('[data-haai-batch-ids]');
	var batchSubmit = qs('[data-haai-batch-submit]');
	var batchEstimate = qs('[data-haai-batch-estimate]');
	var withImage = qs('input[name="with_image"]');

	/* ------------------------------------------------------------------
	 * Transport
	 * ---------------------------------------------------------------- */

	function filterParams() {
		var p = new URLSearchParams();
		p.set('nonce', cfg.nonce || '');
		p.set('q', (qs('[data-haai-pq]') || { value: '' }).value.trim());
		p.set('page', page);
		p.set('per', per);
		p.set('children', childToggle && childToggle.checked ? '1' : '0');
		Object.keys(chosenCats).forEach(function (id) { p.append('cat[]', id); });
		qsa('[data-haai-pstatus] option:checked').forEach(function (o) { p.append('status[]', o.value); });
		var t = qs('[data-haai-ptype]');
		if (t && t.value) p.set('type', t.value);
		var s = qs('[data-haai-pstock]');
		if (s && s.value) p.set('stock', s.value);
		qsa('[data-haai-pcontent] option:checked').forEach(function (o) { p.append('content[]', o.value); });
		return p;
	}

	function call(action, extra) {
		var p = filterParams();
		if (extra) {
			Object.keys(extra).forEach(function (k) { p.set(k, extra[k]); });
		}
		p.set('action', action);
		return fetch(cfg.ajax, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8' },
			body: p.toString()
		}).then(function (r) { return r.json(); });
	}

	function busy(flag) {
		loading = !!flag;
		if (pager) pager.classList.toggle('is-busy', loading);
	}

	/* ------------------------------------------------------------------
	 * Category tree
	 * ---------------------------------------------------------------- */

	function indexTerms(rows) {
		terms = rows || [];
		kidsOf = {};
		nodeById = {};
		terms.forEach(function (row) {
			(kidsOf[row.parent] = kidsOf[row.parent] || []).push(row);
			nodeById[row.id] = { row: row, children: [], input: null, branch: null };
		});
	}

	/** Does this node, or anything under it, match the tree search? */
	function matches(node) {
		if (!treeQuery) return true;
		if (node.row.name.toLowerCase().indexOf(treeQuery) !== -1) return true;
		return (kidsOf[node.row.id] || []).some(function (kid) { return matches(nodeById[kid.id]); });
	}

	function descendantsOf(node, acc) {
		acc = acc || [];
		(kidsOf[node.row.id] || []).forEach(function (kid) {
			acc.push(kid.id);
			descendantsOf(nodeById[kid.id], acc);
		});
		return acc;
	}

	/** Leaves under a node — the count basis for a parent's checkbox state. */
	function selectableLeaves(node) {
		var kids = kidsOf[node.row.id] || [];
		if (!kids.length) return [node.row.id];
		var out = [];
		kids.forEach(function (kid) { out = out.concat(selectableLeaves(nodeById[kid.id])); });
		return out;
	}

	function renderTree() {
		if (!treeBox) return;
		treeBox.innerHTML = '';
		var roots = (kidsOf[0] || []).slice();
		if (!roots.length) {
			var none = document.createElement('p');
			none.className = 'description';
			none.textContent = i18n.noCat || '—';
			treeBox.appendChild(none);
			return;
		}
		var ul = document.createElement('ul');
		ul.setAttribute('role', 'tree');
		roots.forEach(function (row) { ul.appendChild(treeItem(nodeById[row.id], 0)); });
		treeBox.appendChild(ul);
		refreshTreeChecks();
	}

	function treeItem(node, depth) {
		var li = document.createElement('li');
		li.className = 'haai-tree__item';
		li.setAttribute('role', 'treeitem');

		var kids = (kidsOf[node.row.id] || []).filter(function (row) { return matches(nodeById[row.id]); });
		// matches() already folds in "this name hits", so one test is enough.
		if (treeQuery && !matches(node)) { li.hidden = true; }

		var row = document.createElement('span');
		row.className = 'haai-tree__row';
		row.style.setProperty('--haai-tree-depth', depth);

		var twist = document.createElement('button');
		twist.type = 'button';
		twist.className = 'haai-tree__twist' + (kids.length ? '' : ' is-leaf');
		twist.setAttribute('aria-label', kids.length ? 'باز/بسته' : '');
		twist.setAttribute('aria-expanded', kids.length ? 'true' : 'false');
		twist.tabIndex = kids.length ? 0 : -1;

		var box = document.createElement('input');
		box.type = 'checkbox';
		box.className = 'haai-tree__check';
		box.value = node.row.id;
		box.id = 'haai-cat-' + node.row.id;
		node.input = box;
		box.setAttribute('aria-label', node.row.name);

		var label = document.createElement('label');
		label.className = 'haai-tree__label';
		label.setAttribute('for', box.id);
		label.innerHTML = esc(node.row.name) + ' <em class="haai-tree__count">' + esc(node.row.count) + '</em>';

		row.appendChild(twist);
		row.appendChild(box);
		row.appendChild(label);
		li.appendChild(row);

		var branch = null;
		if (kids.length) {
			branch = document.createElement('ul');
			branch.className = 'haai-tree__branch';
			branch.setAttribute('role', 'group');
			kids.forEach(function (kid) { branch.appendChild(treeItem(nodeById[kid.id], depth + 1)); });
			li.appendChild(branch);
		}
		node.branch = branch;

		on(twist, 'click', function () {
			if (!branch) return;
			branch.hidden = !branch.hidden;
			twist.setAttribute('aria-expanded', branch.hidden ? 'false' : 'true');
			twist.classList.toggle('is-closed', branch.hidden);
		});

		on(box, 'change', function () {
			// "Include sub-categories" decides whether ticking a parent means
			// only that node or its whole subtree.
			var ids = (childToggle && childToggle.checked) ? [node.row.id].concat(descendantsOf(node)) : [node.row.id];
			ids.forEach(function (id) {
				if (box.checked) chosenCats[id] = 1; else delete chosenCats[id];
			});
			refreshTreeChecks();
			go(1);
		});

		return li;
	}

	/** Checked / indeterminate / empty for every parent, from the leaves. */
	function refreshTreeChecks() {
		terms.forEach(function (row) {
			var node = nodeById[row.id];
			if (!node || !node.input) return;
			var leaves = selectableLeaves(node);
			var hit = leaves.filter(function (id) { return chosenCats[id]; }).length;
			node.input.checked = hit > 0 && hit === leaves.length;
			node.input.indeterminate = hit > 0 && hit < leaves.length;
		});
	}

	var treeTimer = null;
	on(treeQ, 'input', function () {
		if (treeTimer) clearTimeout(treeTimer);
		treeTimer = setTimeout(function () {
			treeQuery = treeQ.value.trim().toLowerCase();
			renderTree();
		}, 200);
	});
	on(childToggle, 'change', function () { refreshTreeChecks(); go(1); });

	/* ------------------------------------------------------------------
	 * Rows
	 * ---------------------------------------------------------------- */

	function contentBadge(row) {
		var missing = [];
		if (!row.has_excerpt) missing.push('کوتاه');
		if (!row.has_content) missing.push('توضیح');
		if (!row.has_thumb) missing.push('تصویر');
		if (!missing.length) return '<span class="haai-badge haai-badge--on">کامل</span>';
		return '<span class="haai-badge haai-badge--warn" title="بدون: ' + esc(missing.join('، ')) + '">ناقص · ' + esc(missing.length) + '</span>';
	}

	function renderRows(d) {
		body.innerHTML = '';
		var rows = (d && d.rows) || [];

		if (!rows.length) {
			var tr = document.createElement('tr');
			tr.innerHTML = '<td colspan="7"><div class="haai-empty"><span class="haai-empty__title">'
				+ esc(i18n.empty || '—') + '</span></div></td>';
			body.appendChild(tr);
		}

		rows.forEach(function (row) {
			var tr = document.createElement('tr');
			tr.innerHTML =
				'<td class="haai-col-check"><input type="checkbox" class="haai-row-check" value="' + esc(row.id) +
					'" data-title="' + esc(row.title) + '" aria-label="' + esc(row.title) + '"></td>' +
				'<td>' + (row.thumb
					? '<img src="' + esc(row.thumb) + '" alt="" width="44" height="44" loading="lazy" class="haai-prod-thumb">'
					: '<span class="haai-prod-thumb is-none" aria-hidden="true"></span>') + '</td>' +
				'<td class="haai-prod-title"><a href="' + esc(cfg.screen) + '&product=' + encodeURIComponent(row.id) + '">' + esc(row.title) + '</a>' +
					'<span class="haai-prod-meta">#' + esc(row.id) + (row.type ? ' · ' + esc(row.type) : '') + (row.stock ? ' · ' + esc(row.stock) : '') + '</span></td>' +
				'<td>' + (row.sku ? esc(row.sku) : '<span class="haai-dim">—</span>') + '</td>' +
				'<td>' + (row.price ? esc(row.price) : '<span class="haai-dim">—</span>') + '</td>' +
				'<td>' + ((row.cats && row.cats.length) ? esc(row.cats.join('، ')) : '<span class="haai-dim">—</span>') + '</td>' +
				'<td>' + contentBadge(row) + '</td>';
			body.appendChild(tr);
		});

		page = (d && d.page) || page;
		pages = Math.max(1, (d && d.pages) || 1);
		if (counter) counter.textContent = page + ' / ' + pages;
		if (info) info.textContent = ((d && d.total) || 0) + ' محصول';
		if (pager) pager.hidden = false;
		qsa('.haai-row-check').forEach(function (box) {
			box.checked = !!selected[box.value];
			on(box, 'change', function () { toggle(box.value, box.getAttribute('data-title'), box.checked); });
		});
		syncHead();
		syncSelection();
	}

	function syncHead() {
		if (!allBox) return;
		var boxes = qsa('.haai-row-check');
		var hit = boxes.filter(function (b) { return selected[b.value]; }).length;
		allBox.checked = boxes.length > 0 && hit === boxes.length;
		allBox.indeterminate = hit > 0 && hit < boxes.length;
	}

	allBox && on(allBox, 'change', function () {
		qsa('.haai-row-check').forEach(function (b) {
			b.checked = allBox.checked;
			toggle(b.value, b.getAttribute('data-title'), allBox.checked);
		});
	});

	/** Keeping the title with the id is what lets the summary line be honest. */
	function toggle(id, title, onOff) {
		if (onOff) selected[id] = title || ('#' + id);
		else delete selected[id];
		syncSelection();
	}

	function clearSelection() {
		selected = {};
		qsa('.haai-row-check').forEach(function (b) { b.checked = false; });
		syncHead();
		syncSelection();
	}

	function countSelected() { return Object.keys(selected).length; }

	function syncSelection() {
		var n = countSelected();
		if (selBar) selBar.hidden = n === 0;
		if (selCount) selCount.textContent = n + ' ' + (i18n.selected || 'selected');
		if (batchIds) batchIds.value = n ? JSON.stringify(Object.keys(selected).map(Number)) : '';
		if (batchSubmit) batchSubmit.disabled = n === 0;
		var img = withImage && withImage.checked && cfg.images;
		if (batchEstimate) {
			var base = batchEstimate.getAttribute('data-base') || '';
			batchEstimate.textContent = base + (n ? ' — ' + (i18n.estimate || '') + ': ' + n * (img ? 2 : 1) : '');
		}
	}
	withImage && on(withImage, 'change', syncSelection);

	on(qs('[data-haai-selclear]'), 'click', clearSelection);

	on(qs('[data-haai-selall]'), 'click', function () {
		if (!window.confirm(i18n.confirmAll || 'Select all?')) return;
		call('haai_pc_product_ids', { page: 1, per: CAP })
			.then(function (d) {
				if (!d || !d.ok) return;
				(d.ids || []).forEach(function (id) { selected[String(id)] = '#' + id; });
				if (d.truncated && i18n.truncated) window.alert(i18n.truncated);
				qsa('.haai-row-check').forEach(function (b) { b.checked = !!selected[b.value]; });
				syncHead();
				syncSelection();
			})
			.catch(function () {});
	});

	/* ------------------------------------------------------------------
	 * Driving the list
	 * ---------------------------------------------------------------- */

	function go(toPage) {
		if (loading) return;
		page = toPage || page;
		busy(true);
		if (body) body.innerHTML = '<tr><td colspan="7"><span class="description">' + esc(i18n.loading || '…') + '</span></td></tr>';
		call('haai_pc_products')
			.then(function (d) {
				busy(false);
				if (!d || !d.ok) {
					if (body) body.innerHTML = '<tr><td colspan="7">' + esc(d && d.error ? d.error : (i18n.fail || '—')) + '</td></tr>';
					return;
				}
				renderRows(d);
			})
			.catch(function () { busy(false); if (body) body.innerHTML = '<tr><td colspan="7">' + esc(i18n.fail || '—') + '</td></tr>'; });
	}

	var goTimer = null;
	on(qs('[data-haai-pq]'), 'input', function () {
		if (goTimer) clearTimeout(goTimer);
		goTimer = setTimeout(function () { go(1); }, 350);
	});
	on(qs('[data-haai-pgo]'), 'click', function () { go(1); });
	qsa('[data-haai-pstatus],[data-haai-ptype],[data-haai-pstock],[data-haai-pcontent]').forEach(function (el) {
		on(el, 'change', function () { go(1); });
	});
	on(qs('[data-haai-pprev]'), 'click', function () { if (page > 1) { page--; go(); } });
	on(qs('[data-haai-pnext]'), 'click', function () { if (page < pages) { page++; go(); } });

	// Batch submit guards itself: an empty selection is caught before the post.
	on(qs('[data-haai-batch-form]'), 'submit', function (e) {
		if (!countSelected()) { e.preventDefault(); return; }
		var n = countSelected();
		var img = withImage && withImage.checked && cfg.images;
		var total = n * (img ? 2 : 1);
		if (!window.confirm((i18n.estimate || '') + ': ' + n + ' → ' + total + ' requests')) e.preventDefault();
	});

	/* ------------------------------------------------------------------
	 * Boot
	 * ---------------------------------------------------------------- */

	if (batchEstimate) batchEstimate.setAttribute('data-base', batchEstimate.textContent);

	fetch(cfg.ajax + '?action=haai_pc_categories&nonce=' + encodeURIComponent(cfg.nonce || ''), { credentials: 'same-origin' })
		.then(function (r) { return r.json(); })
		.then(function (d) {
			indexTerms(d && d.ok ? d.terms : []);
			renderTree();
		})
		.catch(function () { renderTree(); });

	go(1);
})();
